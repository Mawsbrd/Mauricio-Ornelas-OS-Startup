#ifndef auth_h
#define auth_h
#include <string>

using namespace std;

void prompt();
void login(string name);


#endif
