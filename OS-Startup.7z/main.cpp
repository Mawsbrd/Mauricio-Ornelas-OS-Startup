#include <iostream>
#include "auth.h"

using namespace std;

int main()
{
	prompt();
	string name;
	getline(cin, name);
	login(name);


	return 0;
}

