#include <iostream>
#include <string>
#include "auth.h"
#include <atomic>
using namespace std;

void prompt() 
{
	cout << "______________________________________________" << endl;
	cout << " _    _ ___________ ___________   _____ _____ " << endl;
	cout << "| |  | |_   _| ___ \\  ___|  _  \\ |  _  /  ___|" << endl;
	cout << "| |  | | | | | |_/ / |__ | | | | | | | \\ `--. " << endl;
	cout << "| |/\\| | | | |    /|  __|| | | | | | | |`--. \\" << endl;
	cout << "\\  /\\  /_| |_| |\\ \\| |___| |/ /  \\ \\_/ /\\__/ /" << endl;
	cout << " \\/  \\/ \\___/\\_| \\_\\____/|___/    \\___/\\____/ \n" << endl;
	cout << "______________________________________________" << endl;
	cout << "Please enter ID: ";
}

void login(string name)
{
	cout << "Logging in as " << name << endl;
	for (int i = 0; i < 10; i++)
	{
		cout << ".\n";
	}
	cout << "Welcome to Wired OS, "<< name << "\n\n\n";
	string exit;
	while (exit != "Y")
	{
		cout << "Enter 'Y' to close: ";
		cin >> exit;
	}
}